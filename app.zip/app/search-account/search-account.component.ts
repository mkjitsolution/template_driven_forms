import { Component, OnInit } from '@angular/core';
import { AccountsService } from '../accounts.service';
import { Accounts } from '../accounts';

@Component({
  selector: 'app-search-account',
  templateUrl: './search-account.component.html',
  styleUrls: ['./search-account.component.css']
})
export class SearchAccountComponent implements OnInit {
  accountsService : AccountsService;

  constructor(accountsService : AccountsService) {
    this.accountsService = accountsService;
    
   }

  ngOnInit() {
  }

  letsSearch(phone)
  {
    console.log(phone.value);
    let acc:Accounts  = this.accountsService.searchAccountsByPhone(phone.value);
    if(acc != null)
    {
      alert(" Record Found : "+acc.accountName+","+acc.phone+" , "+acc.email+" , "+acc.balance);
    }
    else{
      alert(" Record Not Found "+phone.value);
    }
   
  }
}
