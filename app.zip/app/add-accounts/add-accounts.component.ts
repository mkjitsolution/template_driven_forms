import { Component, OnInit } from '@angular/core';
import { Accounts } from '../accounts';
import { AccountsService } from '../accounts.service';

@Component({
  selector: 'app-add-accounts',
  templateUrl: './add-accounts.component.html',
  styleUrls: ['./add-accounts.component.css']
})
export class AddAccountsComponent implements OnInit {
  accountModel = new Accounts('',0,0,'');
  
  accountsService : AccountsService;

  constructor(accountsService : AccountsService) {
    this.accountsService = accountsService;
   }

  ngOnInit() {
    
  }
  submitingAccounts()
  {
    this.accountsService.addAccounts(this.accountModel);
  }
}//end class
