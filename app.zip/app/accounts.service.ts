import { Injectable } from '@angular/core';
import { Accounts } from './accounts';

@Injectable({
  providedIn: 'root'
})
export class AccountsService {

  accounts : Array<Accounts>= [];
  updatableAccounts : Accounts = new Accounts('',0,0,'');;


  constructor() { 
    let a1 = new Accounts('ashish',2000,9654144814,'ashish@gmail.com');
    let a2 = new Accounts('ramesh',2000,9654144815,'ramesh@gmail.com');
    this.accounts.push(a1);
    this.accounts.push(a2);
  }

  addAccounts(a:Accounts)
  {
    this.accounts.push(a);
  }

  getAllAccounts()
  {
    return this.accounts;
  }

  setUpdatableAccounts(uacc: Accounts)
  {
    this.updatableAccounts = uacc;

    console.log(" ----------- Service Set --------------");
    let a:Accounts = this.updatableAccounts;
    console.log(" accountName "+a.accountName);
    console.log(" balance "+a.balance);
    console.log(" phone Set "+a.phone);
    console.log(" email "+a.email);
    
  }

  
  searchAccountsByPhone(searchPhone)
  {
    let isFound : boolean = false;
    for(let acc of this.accounts)
    {
        if(acc.phone == searchPhone)
        {
            isFound = true;
            return acc;
            break;
        }
    }
    if(isFound == false) return null;
  }
 

}//end class
