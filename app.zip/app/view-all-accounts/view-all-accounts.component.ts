import { Component, OnInit } from '@angular/core';
import { AccountsService } from '../accounts.service';
import { Accounts } from '../accounts';

@Component({
  selector: 'app-view-all-accounts',
  templateUrl: './view-all-accounts.component.html',
  styleUrls: ['./view-all-accounts.component.css']
})
export class ViewAllAccountsComponent implements OnInit {

  accounts : Array<Accounts> = [];
  accountsService : AccountsService;
  updatableAccount : Accounts;
  isEditable:boolean = false;

  constructor(accountsService : AccountsService) {
    this.accountsService = accountsService;
   }

  ngOnInit() {
    this.accounts = this.accountsService.getAllAccounts();
  }

  doEdit(uacc:Accounts)
  {
    
    this.isEditable = true;
    console.log(" ----------- Update All doEdit event --------------");
       
    this.updatableAccount = uacc;
    
    //this.accountsService.setUpdatableAccounts(uacc);
  }
}
