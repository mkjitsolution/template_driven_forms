export class Accounts {

    accountName:string;
    balance:number;
    phone:number;
    email:string;

    constructor(
        accountName:string,
        balance:number,
        phone:number,
        email:string
    )
    {
        this.accountName = accountName;
        this.balance = balance;
        this.phone = phone;
        this.email = email;
    }
}//end of class
