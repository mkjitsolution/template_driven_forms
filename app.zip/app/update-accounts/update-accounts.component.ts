import { Component, OnInit, Input } from '@angular/core';
import { AccountsService } from '../accounts.service';
import { Accounts } from '../accounts';

@Component({
  selector: 'app-update-accounts',
  templateUrl: './update-accounts.component.html',
  styleUrls: ['./update-accounts.component.css']
})
export class UpdateAccountsComponent implements OnInit {

  accountsService : AccountsService;
  @Input() updatableAccount : Accounts;

  
  constructor(accountsService : AccountsService) {
    this.accountsService = accountsService;
    
   }

  ngOnInit() {
    
  }
  doUpdate()
  {
    console.log("---> doUpdate Update Accounts"+this.updatableAccount.phone+"");
     this.accountsService.setUpdatableAccounts(this.updatableAccount);
  }

}
